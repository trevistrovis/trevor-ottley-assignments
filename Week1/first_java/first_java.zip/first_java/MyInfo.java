public class MyInfo {

    public static void main(String[] args){
        System.out.println("My name is Trevor Ottley");
        System.out.println("I am 28 years old");
        System.out.println("My hometown is Geneva, NY");
    }
    
}
